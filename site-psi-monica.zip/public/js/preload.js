function preload(){
    document.querySelector("#preload").style.display = "none";
    document.querySelector("#content").style.display = "block";
}